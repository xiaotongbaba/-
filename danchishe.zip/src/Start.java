import javax.swing.*;

public class Start {
    public static void main(String[] args) {
        JFrame jFrame=new JFrame();

        jFrame.setTitle("王金宇是个大**");//标题
        jFrame.setBounds(10,10,900,720);//窗口位置和大小
        jFrame.setResizable(false);//固定窗口大小不可变
        jFrame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);//设置可关闭
        jFrame.add(new Gamepanel());//把面板放进容器
        jFrame.setVisible(true);//设置窗口可见
    }
}
